sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("ns.FioriLivrosHTML5Module.controller.DetailObjectNotFound", {});
});